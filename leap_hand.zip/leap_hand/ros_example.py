#!/usr/bin/env python3
import os
import sys
import time
import numpy as np
import rospy
from sensor_msgs.msg import JointState
from leap_hand_utils.dynamixel_client import *
import leap_hand_utils.leap_hand_utils as lhu
from leap_hand.srv import *
from std_msgs.msg import String

# This is example code, it reads the position from LEAP Hand and commands it
# Be sure to query the services only when you need it
# This way you don't clog up the communication lines and you get the newest data possible
class r:
    def __init__(self):        
        self.pub_hand = rospy.Publisher("/leaphand_node/cmd_ones", JointState, queue_size = 3) 
        rospy.Subscriber('human_gesture', String, self.gesture_callback)
        self.gesture_positions = {
            "rock": np.array([np.radians(183), np.radians(265), np.radians(223), np.radians(278),
                              np.radians(172), np.radians(270), np.radians(230), np.radians(300),
                              np.radians(164), np.radians(264), np.radians(244), np.radians(273),
                              np.radians(140), np.radians(87), np.radians(275), np.radians(212)]),
       
            "paper": np.array([np.radians(0)] * 16),  # All joints flat for open fingers

            "scissors": np.array([np.radians(180), np.radians(166), np.radians(169),
                                  np.radians(183), np.radians(180), np.radians(180),
                                  np.radians(180), np.radians(180), np.radians(180),
                                  np.radians(302), np.radians(175), np.radians(213),
                                  np.radians(125), np.radians(66), np.radians(268),
                                  np.radians(212)]),
        }
    def gesture_callback(self, msg):
        gesture = msg.data
        rospy.loginfo(f"Received gesture: {gesture}")
        stater = JointState()
        
        # Set joint positions based on the detected gesture
        if gesture == "rock":
            print("paper")
            stater.position  = self.gesture_positions["paper"]
        elif gesture == "paper":
            print("sciss")
            stater.position  = self.gesture_positions["scissors"]
        elif gesture == "scissors":
            print("roc")
            stater.position  = self.gesture_positions["rock"]
        print(stater.position)
        self.pub_hand.publish(stater)  ##choose the right embodiment here
        rospy.loginfo(f"Published position")

           
if __name__ == "__main__":
    rospy.init_node("publisher")
    telekinesis_node = r()
    rospy.spin()
