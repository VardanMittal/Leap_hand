#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

class GesturePublisher:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('gesture_publisher')
        
        # Create a publisher for the "human_gestures" topic
        self.pub = rospy.Publisher('human_gesture', String, queue_size=10)
        
        # Define the rate at which to publish (e.g., 1 Hz)
        self.rate = rospy.Rate(1)  # 20 Hz

    def run(self):
        while not rospy.is_shutdown():
            # Prepare the gesture message
            gesture_message = String()
            gesture_message.data = "paper"
            
            # Publish the gesture
            self.pub.publish(gesture_message)
            rospy.loginfo(f"Published gesture: {gesture_message.data}")
            
            self.rate.sleep()

if __name__ == "__main__":
    try:
        gesture_publisher = GesturePublisher()
        gesture_publisher.run()
    except rospy.ROSInterruptException:
        rospy.logerr() 